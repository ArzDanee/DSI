(function($) {
    "use strict";

    $(document).ready(function() {
        new WOW().init();
    });

})(jQuery);